---
layout: page
title: Hello
subtitle: My name is Pudhina
sitemap:
  priority: 0.9
---

<img src="{{ '/assets/img/pudhina.jpg' | prepend: site.baseurl }}" id="about-img">

<div id="describe-text">
	<p>A simple, minimal Jekyll theme for a personal web page and blog, focusing on white space and readability</p>
	<p>Fork and use the theme from the <strong> <a href="https://github.com/knhash/Pudhina"> repository</a> </strong></p>
</div>